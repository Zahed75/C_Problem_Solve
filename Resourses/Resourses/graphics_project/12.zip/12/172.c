#include<stdio.h>
#include<math.h>
main(){
   int i,k,nm,pct,count,crt[50];
   int eot[50],lot[50],est[50],eft[50],1st[50],1ft[50],list[50],slack[50];
   int snode,fnode;

   int s[] =
   int f[] =
   int t[] =



}
