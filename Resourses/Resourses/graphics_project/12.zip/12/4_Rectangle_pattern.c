#include <stdio.h>

int main()
{
	int a, b, columns,rows;

	printf("Enter number of rows: ");
	scanf("%d",&rows);

	printf("Enter number of columns: ");
	scanf("%d",&columns);

	for(a=1; a<=rows; ++a)
	{
		for(b=1; b<=columns; ++b)
		{
			printf("* ");
		}
		printf("\n");
	}
	return 0;
}
