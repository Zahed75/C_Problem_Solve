#include <stdio.h>
main()

{
    int a;
    a = 100;
    //point:

    do {
        printf("The value of a is :%d \n",a);
        a++;
    }
    while(a <= 202);
    //*goto point;*/
}
