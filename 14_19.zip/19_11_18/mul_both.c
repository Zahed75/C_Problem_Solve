#include<stdio.h>


void main ()
{
    int i;


    for(i = 2;i<=20; i++)

        printf("%d \n",i*i);

     //printf("%d \n",i+i);

     // printf("%d \n",i);



}

