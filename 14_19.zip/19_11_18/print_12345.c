#include<stdio.h>
#include<conio.h>
int main(){

 int i,j;
 for(i=1;5>=i;i++){
    for(j=i;j<=5;j++)
     printf("+");
     printf("\n");


 }

}
