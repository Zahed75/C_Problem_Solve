#include<stdio.h>

main()
{
    int i,j;

    for(i=0; i<4; i++)
        for(j=2;j>0; j--)
        printf("%d %d \n",i ,j);
}
