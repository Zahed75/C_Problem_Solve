#include<stdio.h>
main()
{
    /*
    int i,j;
    for(i=0;i<2; i++)
        for(j=5;j>0;j--)
        printf("%d \n",i*j);
        */
        int i,j;
        for(i=0;i<=2;i++)
            for(j=0;j<=2;j++)
               printf("%d \n",i+j);

}
