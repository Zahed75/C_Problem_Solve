#include<stdio.h>
#include<conio.h>
int main()
{
 char sham;

 printf("%d",sizeof(char));


}
