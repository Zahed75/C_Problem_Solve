#include <stdio.h>
main()

{
    int x , count;

    for(count = 0;count<= 9; count++)

    {
       printf("%d \t",count);
    }
}

