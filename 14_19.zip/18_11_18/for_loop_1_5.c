#include<stdio.h>
int main(){

  int i,j,k;
  for(i=1;5>=i;i++){

        for(j=1;j<=5;j++)
            //printf(" ");
     printf("%d",i);
     printf("\n");

  }

}
