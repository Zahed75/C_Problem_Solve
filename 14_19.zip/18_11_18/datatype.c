#include<stdio.h>

int main()

{
    int num;

    num = '20';

    //printf("%c",num);
    printf("%d",sizeof(int));

    printf("\n%d",sizeof(float));

    printf("\n%d",sizeof(char));


    printf("\n%d",sizeof(double));

}
