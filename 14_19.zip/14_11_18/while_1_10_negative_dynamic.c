#include<stdio.h>
int main(){

     int i;

     printf("Please Enter Your Number:");
     scanf("%d",&i);

     while(i>=0){

        printf(" %d \n ",i);
        i--;
     }

}

