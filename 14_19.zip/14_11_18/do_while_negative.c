#include<stdio.h>
int main(){

      int i = 10;

      do{
        printf(" The Number Is = %d \n",i);
        i--;


      }while(i>=0);
      getch();


}

