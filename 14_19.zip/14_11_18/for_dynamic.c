#include<stdio.h>
int main(){

    int i;
    int condition;

    printf("Please Enter Your Starting Number:");
    scanf("%d",&i);

     printf("Please Enter Your Ending Number:");
    scanf("%d",&condition);

    for(i=i; i<condition; i++){

       printf("\n %d \n ",i);
    }

}

